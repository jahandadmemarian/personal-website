function init() {
    var w = .01*Math.max(window.innerWidth, document.body.clientWidth), h = 1.8*Math.max(window.innerHeight, document.body.clientHeight);
    var clouder = document.getElementById('clouder');
    
    clouder.style.border = "0px solid black";
    clouder.style.width = asPixels(w * 90 / 3);
    clouder.style.height = asPixels(h * 1 / 3);
    clouder.style.position = "absolute";
    clouder.style.left = asPixels(w / 6);
    clouder.style.top = asPixels(h / 6);
    clouder.style.border = "0px solid black";
    
    window.clouder = new Clouder({
        container: clouder,
        tags: createTags(),
        colorMax: "#00FA9A",
        colorMin: "#FF0000",
        stepAngle: .01,
    });
} // init
function createTags() {
    var elems = [];
    elems.push({text: "HTML", id: "1", weight: 1});
    elems.push({text: "CSS", id: "2", weight: 1});
    elems.push({text: "JavaScript", id: "3", weight: 1});
    elems.push({text: "Git", id: "4", weight: 1});
    elems.push({text: "Github", id: "5", weight: 1});
    elems.push({text: "UX", id: "6", weight: 1});
    elems.push({text: "UI", id: "7", weight: 1});
    elems.push({text: "SEO", id: "8", weight: 1});
    elems.push({text: "WordPress", id: "9", weight: 1});
    elems.push({text: "XML", id: "10", weight: 1});
    elems.push({text: "Node.js", id: "11", weight: 1});
    elems.push({text: "NPM", id: "12", weight: 1});
    elems.push({text: "Three.js", id: "13", weight: 1});
    elems.push({text: "jQuery", id: "14", weight: 1});
    elems.push({text: "Bootstrap", id: "15", weight: 1});
    elems.push({text: "Sass", id: "16", weight: 1});
   return elems;
} // createTags
